# MarketHub - OLX-Style Marketplace

## Overview
MarketHub is a full-stack marketplace web application for buying and selling used products locally. It features user authentication, product listings with photos, search and filtering, buyer-seller chat, favorites/wishlist, and a seller dashboard.

## Tech Stack
- **Frontend**: React + TypeScript + TailwindCSS + shadcn/ui
- **Backend**: Node.js + Express
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (supports Google, GitHub, email/password)
- **Real-time**: WebSocket for chat messaging
- **File Upload**: Multer for image uploads

## Project Structure
```
client/
├── src/
│   ├── pages/           # Page components
│   │   ├── landing.tsx      # Public landing page
│   │   ├── home.tsx         # Authenticated home with products
│   │   ├── product-detail.tsx
│   │   ├── create-listing.tsx
│   │   ├── edit-listing.tsx
│   │   ├── dashboard.tsx    # Seller dashboard
│   │   ├── favorites.tsx
│   │   ├── messages.tsx
│   │   ├── conversation.tsx
│   │   ├── profile.tsx
│   │   └── search-results.tsx
│   ├── components/      # Reusable components
│   │   ├── product-card.tsx
│   │   ├── product-grid.tsx
│   │   ├── category-pills.tsx
│   │   └── ui/          # shadcn components
│   ├── hooks/
│   │   └── useAuth.ts   # Authentication hook
│   └── lib/
│       ├── queryClient.ts
│       └── authUtils.ts
server/
├── index.ts            # Express server entry
├── routes.ts           # API routes
├── storage.ts          # Database operations
├── replitAuth.ts       # Replit Auth setup
├── db.ts               # Database connection
└── seed.ts             # Category seeding
shared/
└── schema.ts           # Drizzle models & types
```

## Database Schema
- **users**: User accounts with Replit Auth integration
- **products**: Product listings with images, pricing, condition
- **categories**: Product categories (Electronics, Vehicles, etc.)
- **favorites**: User's saved products
- **conversations**: Chat threads between buyers and sellers
- **messages**: Individual chat messages
- **sessions**: Auth sessions for Replit Auth

## Key Features
1. **Authentication**: Login via Google, GitHub, or email/password
2. **Product Listings**: Create, edit, delete listings with multiple photos
3. **Search & Filter**: Search by title/description, filter by category, price, condition
4. **Favorites**: Save products to wishlist
5. **Real-time Chat**: WebSocket-powered messaging between buyers and sellers
6. **Seller Dashboard**: View listings, track views, manage products

## API Endpoints
- `GET/POST /api/products` - List/create products
- `GET/PATCH/DELETE /api/products/:id` - Single product operations
- `GET/POST/DELETE /api/favorites/:productId` - Favorites management
- `GET/POST /api/conversations` - Conversations
- `GET/POST /api/conversations/:id/messages` - Messages
- `GET/PATCH /api/users/profile` - User profile
- `GET /api/categories` - Product categories
- `GET /api/my/listings` - Current user's listings

## Running the Project
The application runs on port 5000 using `npm run dev`.
- Frontend and backend are served together
- Images are stored in `/uploads` directory
- Database schema pushed with `npm run db:push`

# OLX-Style Marketplace - Design Guidelines

## Design Approach

**Reference:** OLX, Facebook Marketplace, OfferUp, Mercari - modern classifieds platforms

**Rationale:** E-commerce marketplace requiring visual product showcase, trust-building through clean design, and efficient browsing. Card-based layouts maximize product visibility while maintaining scanability.

## Core Design Elements

### Typography
- **Primary Font:** Inter (Google Fonts)
- **Hierarchy:**
  - H1: 36px/bold - Homepage hero, category pages
  - H2: 28px/semibold - Section headers
  - H3: 20px/semibold - Product titles, card headers
  - Body: 16px/regular - Descriptions, details
  - Price: 24px/bold - Product pricing (stands out)
  - Small: 14px/regular - Metadata, timestamps
  - Micro: 12px/medium - Tags, categories, labels

### Layout System
**Spacing Units:** Tailwind units of 3, 4, 6, and 8

**Grid Structure:**
- Homepage: Full-width hero, then max-w-7xl container
- Product Grid: 4 columns desktop (lg:grid-cols-4), 2 tablet (md:grid-cols-2), 1 mobile
- Product Detail: 2-column (60% images, 40% details)
- Dashboard: Sidebar navigation + main content area

### Component Library

**Navigation:**
- Sticky top bar with logo left, search center (40% width), user menu right
- Category pills below header (horizontal scroll on mobile)
- Location selector prominent in header

**Product Cards:**
- Image top (16:12 aspect ratio)
- Price as first text element (bold, large)
- Title below price (2-line truncate)
- Location + timestamp at bottom (small, muted)
- Featured badge overlay (top-left corner)
- Heart icon for favorites (top-right)
- Hover: subtle lift with shadow

**Search & Filters:**
- Prominent search bar with category dropdown and location input
- Sidebar filters on listing pages: Price range, condition, category, distance
- Active filter chips above results (dismissible)
- Sort dropdown: Newest, Price Low/High, Distance

**Product Detail Page:**
- Image gallery left: Large preview + thumbnail strip below
- Info panel right: Price, title, description, seller info card, contact buttons
- Similar listings section below
- Breadcrumb navigation at top

**Chat System:**
- Floating chat button (bottom-right) on product pages
- Chat panel slides in from right (400px width)
- Message list with timestamps
- Input at bottom with attachment icon
- Active conversation list view

**User Profile:**
- Profile header: Avatar, name, member since, rating stars
- Tab navigation: Active Listings, Sold Items, Reviews
- Grid of user's products below

**Seller Dashboard:**
- Sidebar: Dashboard, My Listings, Messages, Favorites, Settings
- Main area: Stats cards (views, messages, active listings)
- Recent activity feed
- Quick actions: "Post New Item" primary button

**Forms (Post Item):**
- Multi-step: Photos → Details → Pricing → Review
- Photo upload: Drag-drop zone, 8 image limit, reorder capability
- Category selector with icons
- Condition dropdown (New, Like New, Good, Fair)
- Price input with currency symbol
- Description textarea with character counter

**Buttons:**
- Primary: Solid, rounded-lg, px-6 py-3
- Secondary: Border outline, same padding
- "Contact Seller": Full-width on mobile, auto width desktop
- "Post Item": Persistent in header (logged in users)
- Image overlay buttons: backdrop-blur-md

**Trust Elements:**
- Verified badge for trusted sellers
- Rating stars (5-star system)
- Review count displayed
- "Member since" dates
- Response time indicator
- Report listing link (subtle, footer of product page)

### Images

**Hero Section:**
Hero banner (500px height desktop, 300px mobile) featuring lifestyle product photography showcasing the marketplace variety - collage style with happy sellers/buyers, various products (electronics, furniture, clothing). Overlay with centered search bar and headline "Buy & Sell Locally". Use backdrop-blur-md for search input background.

**Product Images:**
- Primary product photos in listings (square crop)
- Gallery images on detail pages (original aspect ratio)
- User avatars (48px circles in cards, 120px on profiles)
- Category icons (solid style, 32px)

**Empty States:**
- "No listings found" illustration
- "Start selling" onboarding graphic
- Empty messages/favorites states

**Placeholder Images:**
- Gray background with icon for missing product photos
- Default avatar with initials

## Page Structures

**Homepage:**
- Hero with search (as described above)
- Featured/Promoted listings carousel
- Category grid (8-12 categories with icons + images)
- Recent listings section (4-column grid)
- Location-based "Near You" section
- Trust/safety footer strip

**Listing Pages:**
- Breadcrumb navigation
- Filters sidebar (left 1/4)
- Product grid (right 3/4)
- Pagination at bottom

**Product Detail:**
- Image gallery (left 60%)
- Product info + seller card (right 40%)
- Sticky contact button on scroll
- Description with "Read more" expansion
- Map showing approximate location
- Similar items grid

## Key Principles
1. **Image-first:** Product photos dominate, large and clear
2. **Trust signals:** Ratings, verification, member duration visible
3. **Price clarity:** Bold, prominent pricing on every card
4. **Quick contact:** One-click chat from any product view
5. **Mobile-optimized:** Touch-friendly targets, streamlined mobile posting flow
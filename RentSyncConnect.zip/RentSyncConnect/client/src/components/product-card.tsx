import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, MapPin, Clock } from "lucide-react";
import type { ProductWithSeller } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: ProductWithSeller;
  onFavoriteChange?: () => void;
}

export function ProductCard({ product, onFavoriteChange }: ProductCardProps) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isFavorite, setIsFavorite] = useState(product.isFavorite || false);

  const addFavorite = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/favorites/${product.id}`);
    },
    onSuccess: () => {
      setIsFavorite(true);
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      onFavoriteChange?.();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add to favorites", variant: "destructive" });
    },
  });

  const removeFavorite = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/favorites/${product.id}`);
    },
    onSuccess: () => {
      setIsFavorite(false);
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      onFavoriteChange?.();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove from favorites", variant: "destructive" });
    },
  });

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }

    if (isFavorite) {
      removeFavorite.mutate();
    } else {
      addFavorite.mutate();
    }
  };

  const formatPrice = (price: string | number) => {
    const num = typeof price === "string" ? parseFloat(price) : price;
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  };

  const imageUrl = product.images?.[0] || "/placeholder-product.svg";

  return (
    <Link href={`/product/${product.id}`}>
      <Card className="overflow-hidden hover-elevate cursor-pointer group" data-testid={`card-product-${product.id}`}>
        <div className="relative aspect-[4/3] bg-muted">
          <img
            src={imageUrl}
            alt={product.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.src = "https://placehold.co/400x300/e2e8f0/94a3b8?text=No+Image";
            }}
          />
          {product.featured && (
            <Badge className="absolute top-2 left-2" variant="default">
              Featured
            </Badge>
          )}
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "absolute top-2 right-2 h-8 w-8 rounded-full bg-background/80 backdrop-blur-sm",
              "opacity-0 group-hover:opacity-100 transition-opacity",
              isFavorite && "opacity-100"
            )}
            onClick={handleFavoriteClick}
            disabled={addFavorite.isPending || removeFavorite.isPending}
            data-testid={`button-favorite-${product.id}`}
          >
            <Heart 
              className={cn(
                "h-4 w-4 transition-colors",
                isFavorite ? "fill-red-500 text-red-500" : "text-foreground"
              )} 
            />
          </Button>
        </div>
        <div className="p-3 space-y-2">
          <p className="font-bold text-lg" data-testid={`text-price-${product.id}`}>
            {formatPrice(product.price)}
          </p>
          <h3 className="font-medium text-sm line-clamp-2" data-testid={`text-title-${product.id}`}>
            {product.title}
          </h3>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            {product.location && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {product.location}
              </span>
            )}
            {product.createdAt && (
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDistanceToNow(new Date(product.createdAt), { addSuffix: true })}
              </span>
            )}
          </div>
        </div>
      </Card>
    </Link>
  );
}

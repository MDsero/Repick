import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import type { Category } from "@shared/schema";
import { 
  Laptop, 
  Sofa, 
  Car, 
  Shirt, 
  Dumbbell, 
  Book, 
  Gamepad2, 
  Baby,
  Grid3X3,
  Home,
  Wrench,
  Music,
} from "lucide-react";
import { cn } from "@/lib/utils";

const iconMap: Record<string, any> = {
  laptop: Laptop,
  sofa: Sofa,
  car: Car,
  shirt: Shirt,
  dumbbell: Dumbbell,
  book: Book,
  gamepad: Gamepad2,
  baby: Baby,
  home: Home,
  wrench: Wrench,
  music: Music,
  default: Grid3X3,
};

interface CategoryPillsProps {
  categories: Category[];
  selectedId?: number | null;
  onSelect: (categoryId: number | null) => void;
}

export function CategoryPills({ categories, selectedId, onSelect }: CategoryPillsProps) {
  const getIcon = (icon: string | null) => {
    const IconComponent = iconMap[icon || "default"] || iconMap.default;
    return <IconComponent className="h-4 w-4" />;
  };

  return (
    <ScrollArea className="w-full whitespace-nowrap">
      <div className="flex gap-2 pb-3">
        <Button
          variant={selectedId === null ? "default" : "outline"}
          size="sm"
          className="shrink-0"
          onClick={() => onSelect(null)}
          data-testid="button-category-all"
        >
          <Grid3X3 className="h-4 w-4 mr-2" />
          All
        </Button>
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedId === category.id ? "default" : "outline"}
            size="sm"
            className="shrink-0"
            onClick={() => onSelect(category.id)}
            data-testid={`button-category-${category.slug}`}
          >
            {getIcon(category.icon)}
            <span className="ml-2">{category.name}</span>
          </Button>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}

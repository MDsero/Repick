import { useQuery } from "@tanstack/react-query";
import { ProductGrid } from "@/components/product-grid";
import { CategoryPills } from "@/components/category-pills";
import type { ProductWithSeller, Category } from "@shared/schema";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { SlidersHorizontal, X } from "lucide-react";
import { productConditions } from "@shared/schema";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [minPrice, setMinPrice] = useState<number | undefined>();
  const [maxPrice, setMaxPrice] = useState<number | undefined>();
  const [condition, setCondition] = useState<string | undefined>();
  const [filtersOpen, setFiltersOpen] = useState(false);

  const { data: products = [], isLoading: productsLoading, refetch } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/products", selectedCategory, minPrice, maxPrice, condition],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory) params.set("category", selectedCategory.toString());
      if (minPrice) params.set("minPrice", minPrice.toString());
      if (maxPrice) params.set("maxPrice", maxPrice.toString());
      if (condition) params.set("condition", condition);
      const res = await fetch(`/api/products?${params}`);
      return res.json();
    },
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const clearFilters = () => {
    setSelectedCategory(null);
    setMinPrice(undefined);
    setMaxPrice(undefined);
    setCondition(undefined);
  };

  const hasActiveFilters = selectedCategory || minPrice || maxPrice || condition;

  const FilterContent = () => (
    <div className="space-y-6">
      <div className="space-y-3">
        <Label>Price Range</Label>
        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Min"
            value={minPrice || ""}
            onChange={(e) => setMinPrice(e.target.value ? parseFloat(e.target.value) : undefined)}
            data-testid="input-min-price"
          />
          <Input
            type="number"
            placeholder="Max"
            value={maxPrice || ""}
            onChange={(e) => setMaxPrice(e.target.value ? parseFloat(e.target.value) : undefined)}
            data-testid="input-max-price"
          />
        </div>
      </div>

      <div className="space-y-3">
        <Label>Condition</Label>
        <Select value={condition || ""} onValueChange={(v) => setCondition(v || undefined)}>
          <SelectTrigger data-testid="select-condition">
            <SelectValue placeholder="Any condition" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Any condition</SelectItem>
            {productConditions.map((c) => (
              <SelectItem key={c.value} value={c.value}>
                {c.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {hasActiveFilters && (
        <Button variant="outline" className="w-full" onClick={clearFilters} data-testid="button-clear-filters">
          <X className="h-4 w-4 mr-2" />
          Clear Filters
        </Button>
      )}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        <aside className="hidden lg:block w-64 shrink-0">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <FilterContent />
            </CardContent>
          </Card>
        </aside>

        <div className="flex-1 space-y-6">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-2xl font-bold">Latest Products</h1>
            <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="lg:hidden gap-2" data-testid="button-mobile-filters">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                  {hasActiveFilters && (
                    <span className="bg-primary text-primary-foreground rounded-full h-5 w-5 text-xs flex items-center justify-center">
                      !
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                </SheetHeader>
                <div className="mt-6">
                  <FilterContent />
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {categories.length > 0 && (
            <CategoryPills
              categories={categories}
              selectedId={selectedCategory}
              onSelect={setSelectedCategory}
            />
          )}

          <ProductGrid 
            products={products} 
            isLoading={productsLoading} 
            onFavoriteChange={() => refetch()}
          />
        </div>
      </div>
    </div>
  );
}

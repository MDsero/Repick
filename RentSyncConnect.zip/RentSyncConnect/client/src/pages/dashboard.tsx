import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import type { ProductWithSeller } from "@shared/schema";
import { Plus, Package, Eye, Edit, ExternalLink } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { data: activeProducts = [], isLoading: activeLoading } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/my/listings", "active"],
    queryFn: async () => {
      const res = await fetch("/api/my/listings?status=active");
      return res.json();
    },
  });

  const { data: soldProducts = [], isLoading: soldLoading } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/my/listings", "sold"],
    queryFn: async () => {
      const res = await fetch("/api/my/listings?status=sold");
      return res.json();
    },
  });

  const formatPrice = (price: string | number) => {
    const num = typeof price === "string" ? parseFloat(price) : price;
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  };

  const totalViews = activeProducts.reduce((sum, p) => sum + (p.views || 0), 0);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <h1 className="text-2xl font-bold">My Listings</h1>
        <Link href="/sell">
          <Button className="gap-2" data-testid="button-new-listing">
            <Plus className="h-4 w-4" />
            New Listing
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-active">{activeProducts.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-views">{totalViews}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Items Sold</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-sold">{soldProducts.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList>
          <TabsTrigger value="active" data-testid="tab-active">
            Active ({activeProducts.length})
          </TabsTrigger>
          <TabsTrigger value="sold" data-testid="tab-sold">
            Sold ({soldProducts.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-4">
          <ListingTable 
            products={activeProducts} 
            isLoading={activeLoading}
            formatPrice={formatPrice}
          />
        </TabsContent>

        <TabsContent value="sold" className="mt-4">
          <ListingTable 
            products={soldProducts} 
            isLoading={soldLoading}
            formatPrice={formatPrice}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ListingTable({ 
  products, 
  isLoading,
  formatPrice,
}: { 
  products: ProductWithSeller[]; 
  isLoading: boolean;
  formatPrice: (price: string | number) => string;
}) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="flex items-center gap-4 p-4">
              <Skeleton className="h-16 w-16 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-3 w-24" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground mb-4">No listings yet</p>
          <Link href="/sell">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create your first listing
            </Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {products.map((product) => (
        <Card key={product.id} className="hover-elevate" data-testid={`listing-${product.id}`}>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="h-16 w-16 rounded-lg overflow-hidden bg-muted shrink-0">
              <img 
                src={product.images?.[0] || "https://placehold.co/100x100/e2e8f0/94a3b8?text=No+Image"} 
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start gap-2">
                <h3 className="font-medium truncate">{product.title}</h3>
                {product.status === "sold" && (
                  <Badge variant="secondary">Sold</Badge>
                )}
              </div>
              <p className="text-lg font-bold">{formatPrice(product.price)}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Eye className="h-3 w-3" />
                  {product.views} views
                </span>
                <span>
                  {product.createdAt && formatDistanceToNow(new Date(product.createdAt), { addSuffix: true })}
                </span>
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Link href={`/product/${product.id}`}>
                <Button variant="ghost" size="icon" data-testid={`view-${product.id}`}>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </Link>
              <Link href={`/edit/${product.id}`}>
                <Button variant="ghost" size="icon" data-testid={`edit-${product.id}`}>
                  <Edit className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

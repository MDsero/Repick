import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ProductGrid } from "@/components/product-grid";
import { CategoryPills } from "@/components/category-pills";
import type { ProductWithSeller, Category } from "@shared/schema";
import { useState, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { SlidersHorizontal, X, Search } from "lucide-react";
import { productConditions } from "@shared/schema";

export default function SearchResults() {
  const [location] = useLocation();
  const searchParams = useMemo(() => new URLSearchParams(location.split("?")[1] || ""), [location]);
  const initialQuery = searchParams.get("q") || "";

  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [minPrice, setMinPrice] = useState<number | undefined>();
  const [maxPrice, setMaxPrice] = useState<number | undefined>();
  const [condition, setCondition] = useState<string | undefined>();

  const { data: products = [], isLoading: productsLoading, refetch } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/products", "search", initialQuery, selectedCategory, minPrice, maxPrice, condition],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (initialQuery) params.set("search", initialQuery);
      if (selectedCategory) params.set("category", selectedCategory.toString());
      if (minPrice) params.set("minPrice", minPrice.toString());
      if (maxPrice) params.set("maxPrice", maxPrice.toString());
      if (condition) params.set("condition", condition);
      const res = await fetch(`/api/products?${params}`);
      return res.json();
    },
    enabled: !!initialQuery,
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const clearFilters = () => {
    setSelectedCategory(null);
    setMinPrice(undefined);
    setMaxPrice(undefined);
    setCondition(undefined);
  };

  const hasActiveFilters = selectedCategory || minPrice || maxPrice || condition;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        <aside className="lg:w-64 shrink-0">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>Price Range</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    placeholder="Min"
                    value={minPrice || ""}
                    onChange={(e) => setMinPrice(e.target.value ? parseFloat(e.target.value) : undefined)}
                    data-testid="input-min-price"
                  />
                  <Input
                    type="number"
                    placeholder="Max"
                    value={maxPrice || ""}
                    onChange={(e) => setMaxPrice(e.target.value ? parseFloat(e.target.value) : undefined)}
                    data-testid="input-max-price"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label>Condition</Label>
                <Select value={condition || ""} onValueChange={(v) => setCondition(v || undefined)}>
                  <SelectTrigger data-testid="select-condition">
                    <SelectValue placeholder="Any condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Any condition</SelectItem>
                    {productConditions.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {hasActiveFilters && (
                <Button variant="outline" className="w-full" onClick={clearFilters} data-testid="button-clear-filters">
                  <X className="h-4 w-4 mr-2" />
                  Clear Filters
                </Button>
              )}
            </CardContent>
          </Card>
        </aside>

        <div className="flex-1 space-y-6">
          <div className="flex items-center gap-4">
            <Search className="h-5 w-5 text-muted-foreground" />
            <h1 className="text-2xl font-bold">
              Results for "{initialQuery}"
            </h1>
            <span className="text-muted-foreground">
              ({products.length} {products.length === 1 ? "item" : "items"})
            </span>
          </div>

          {categories.length > 0 && (
            <CategoryPills
              categories={categories}
              selectedId={selectedCategory}
              onSelect={setSelectedCategory}
            />
          )}

          <ProductGrid 
            products={products} 
            isLoading={productsLoading}
            onFavoriteChange={() => refetch()}
          />
        </div>
      </div>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import type { ConversationWithDetails } from "@shared/schema";
import { MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Messages() {
  const { user } = useAuth();
  
  const { data: conversations = [], isLoading } = useQuery<ConversationWithDetails[]>({
    queryKey: ["/api/conversations"],
  });

  const getOtherUser = (conv: ConversationWithDetails) => {
    return conv.buyerId === user?.id ? conv.seller : conv.buyer;
  };

  const getInitials = (otherUser: typeof conversations[0]["buyer"]) => {
    if (otherUser?.firstName && otherUser?.lastName) {
      return `${otherUser.firstName[0]}${otherUser.lastName[0]}`.toUpperCase();
    }
    if (otherUser?.email) {
      return otherUser.email[0].toUpperCase();
    }
    return "U";
  };

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8 space-y-4">
        <h1 className="text-2xl font-bold">Messages</h1>
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="flex items-center gap-4 p-4">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-48" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-4">
      <h1 className="text-2xl font-bold">Messages</h1>

      {conversations.length === 0 ? (
        <div className="text-center py-16">
          <MessageCircle className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">No messages yet</h2>
          <p className="text-muted-foreground mb-6">
            When you contact sellers, your conversations will appear here.
          </p>
          <Link href="/">
            <Button data-testid="button-browse">Browse Products</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {conversations.map((conv) => {
            const otherUser = getOtherUser(conv);
            const isBuyer = conv.buyerId === user?.id;
            
            return (
              <Link key={conv.id} href={`/messages/${conv.id}`}>
                <Card className="hover-elevate cursor-pointer" data-testid={`conversation-${conv.id}`}>
                  <CardContent className="flex items-center gap-4 p-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={otherUser?.profileImageUrl || undefined} className="object-cover" />
                      <AvatarFallback>{getInitials(otherUser)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">
                          {otherUser?.firstName 
                            ? `${otherUser.firstName} ${otherUser.lastName || ""}`
                            : "User"}
                        </span>
                        {(conv.unreadCount ?? 0) > 0 && (
                          <Badge variant="default" className="shrink-0">
                            {conv.unreadCount}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {conv.product.title}
                      </p>
                      {conv.lastMessage && (
                        <p className="text-sm text-muted-foreground truncate">
                          {conv.lastMessage.senderId === user?.id ? "You: " : ""}
                          {conv.lastMessage.content}
                        </p>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground shrink-0">
                      {conv.lastMessageAt && formatDistanceToNow(new Date(conv.lastMessageAt), { addSuffix: true })}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

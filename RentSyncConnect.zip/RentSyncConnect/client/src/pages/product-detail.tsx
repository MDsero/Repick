import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithSeller, Category } from "@shared/schema";
import { productConditions } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { 
  Heart, 
  MessageCircle, 
  MapPin, 
  Clock, 
  Eye, 
  Share2,
  ChevronLeft,
  ChevronRight,
  ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [selectedImage, setSelectedImage] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);

  const { data: product, isLoading } = useQuery<ProductWithSeller>({
    queryKey: ["/api/products", params.id],
    queryFn: async () => {
      const res = await fetch(`/api/products/${params.id}`);
      if (!res.ok) throw new Error("Product not found");
      const data = await res.json();
      setIsFavorite(data.isFavorite || false);
      return data;
    },
  });

  const addFavorite = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/favorites/${params.id}`);
    },
    onSuccess: () => {
      setIsFavorite(true);
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add to favorites", variant: "destructive" });
    },
  });

  const removeFavorite = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/favorites/${params.id}`);
    },
    onSuccess: () => {
      setIsFavorite(false);
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to remove from favorites", variant: "destructive" });
    },
  });

  const startConversation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/conversations", {
        productId: parseInt(params.id!),
        sellerId: product!.sellerId,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setLocation(`/messages/${data.id}`);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to start conversation", variant: "destructive" });
    },
  });

  const handleFavorite = () => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    if (isFavorite) {
      removeFavorite.mutate();
    } else {
      addFavorite.mutate();
    }
  };

  const handleContact = () => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    startConversation.mutate();
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: product?.title,
        url: window.location.href,
      });
    } catch {
      await navigator.clipboard.writeText(window.location.href);
      toast({ title: "Link copied to clipboard" });
    }
  };

  const formatPrice = (price: string | number) => {
    const num = typeof price === "string" ? parseFloat(price) : price;
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  };

  const getConditionLabel = (value: string) => {
    return productConditions.find(c => c.value === value)?.label || value;
  };

  const getInitials = (seller: { firstName?: string | null; lastName?: string | null; email?: string | null } | null | undefined) => {
    if (seller?.firstName && seller?.lastName) {
      return `${seller.firstName[0]}${seller.lastName[0]}`.toUpperCase();
    }
    if (seller?.email) {
      return seller.email[0].toUpperCase();
    }
    return "S";
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-6">
        <Skeleton className="h-6 w-24 mb-6" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <Skeleton className="aspect-[4/3] rounded-lg" />
            <div className="flex gap-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="w-20 h-20 rounded-lg" />
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-40 w-full rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Product Not Found</h1>
        <p className="text-muted-foreground mb-6">This listing may have been removed or doesn't exist.</p>
        <Link href="/">
          <Button>Browse Products</Button>
        </Link>
      </div>
    );
  }

  const images = product.images?.length ? product.images : ["https://placehold.co/600x400/e2e8f0/94a3b8?text=No+Image"];
  const isOwner = user?.id === product.sellerId;

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <Button variant="ghost" size="sm" className="gap-2 mb-4" asChild>
        <Link href="/" data-testid="link-back">
          <ArrowLeft className="h-4 w-4" />
          Back to listings
        </Link>
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <div className="relative aspect-[4/3] bg-muted rounded-lg overflow-hidden">
            <img
              src={images[selectedImage]}
              alt={product.title}
              className="w-full h-full object-contain"
              onError={(e) => {
                e.currentTarget.src = "https://placehold.co/600x400/e2e8f0/94a3b8?text=No+Image";
              }}
            />
            {images.length > 1 && (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm"
                  onClick={() => setSelectedImage(i => i > 0 ? i - 1 : images.length - 1)}
                  data-testid="button-prev-image"
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm"
                  onClick={() => setSelectedImage(i => i < images.length - 1 ? i + 1 : 0)}
                  data-testid="button-next-image"
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </>
            )}
          </div>

          {images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-2">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(i)}
                  className={cn(
                    "w-20 h-20 shrink-0 rounded-lg overflow-hidden border-2 transition-colors",
                    selectedImage === i ? "border-primary" : "border-transparent"
                  )}
                  data-testid={`button-thumbnail-${i}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          <div className="space-y-4 lg:hidden">
            <ProductInfo 
              product={product} 
              formatPrice={formatPrice}
              getConditionLabel={getConditionLabel}
            />
          </div>

          <Card>
            <CardContent className="p-6">
              <h2 className="font-semibold mb-3">Description</h2>
              <p className="text-muted-foreground whitespace-pre-wrap" data-testid="text-description">
                {product.description}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <div className="hidden lg:block">
            <ProductInfo 
              product={product} 
              formatPrice={formatPrice}
              getConditionLabel={getConditionLabel}
            />
          </div>

          <div className="flex gap-2">
            {!isOwner && (
              <Button 
                className="flex-1 gap-2" 
                onClick={handleContact}
                disabled={startConversation.isPending}
                data-testid="button-contact-seller"
              >
                <MessageCircle className="h-4 w-4" />
                {startConversation.isPending ? "Starting..." : "Contact Seller"}
              </Button>
            )}
            {isOwner && (
              <Button className="flex-1" asChild>
                <Link href={`/edit/${product.id}`} data-testid="button-edit">
                  Edit Listing
                </Link>
              </Button>
            )}
            <Button 
              variant="outline" 
              size="icon" 
              onClick={handleFavorite}
              disabled={addFavorite.isPending || removeFavorite.isPending}
              data-testid="button-favorite"
            >
              <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
            </Button>
            <Button variant="outline" size="icon" onClick={handleShare} data-testid="button-share">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>

          <Card>
            <CardContent className="p-4">
              <Link href={`/user/${product.seller.id}`}>
                <div className="flex items-center gap-3 hover-elevate rounded-lg p-2 -m-2 cursor-pointer" data-testid="link-seller">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={product.seller.profileImageUrl || undefined} className="object-cover" />
                    <AvatarFallback>{getInitials(product.seller)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">
                      {product.seller.firstName 
                        ? `${product.seller.firstName} ${product.seller.lastName || ""}`
                        : "Seller"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Member since {product.seller.createdAt && formatDistanceToNow(new Date(product.seller.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ProductInfo({ 
  product, 
  formatPrice, 
  getConditionLabel 
}: { 
  product: ProductWithSeller; 
  formatPrice: (price: string | number) => string;
  getConditionLabel: (value: string) => string;
}) {
  return (
    <div className="space-y-3">
      <p className="text-3xl font-bold" data-testid="text-price">
        {formatPrice(product.price)}
      </p>
      <h1 className="text-xl font-semibold" data-testid="text-title">{product.title}</h1>
      
      <div className="flex flex-wrap gap-2">
        <Badge variant="secondary">{getConditionLabel(product.condition)}</Badge>
        {product.category && <Badge variant="outline">{product.category.name}</Badge>}
      </div>

      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
        {product.location && (
          <span className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {product.location}
          </span>
        )}
        {product.createdAt && (
          <span className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {formatDistanceToNow(new Date(product.createdAt), { addSuffix: true })}
          </span>
        )}
        <span className="flex items-center gap-1">
          <Eye className="h-4 w-4" />
          {product.views} views
        </span>
      </div>
    </div>
  );
}

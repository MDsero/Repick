import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import type { ConversationWithDetails, Message } from "@shared/schema";
import { ArrowLeft, Send, ExternalLink } from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";
import { cn } from "@/lib/utils";

export default function Conversation() {
  const params = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const { data: conversation, isLoading: convLoading } = useQuery<ConversationWithDetails>({
    queryKey: ["/api/conversations", params.id],
  });

  const { data: messages = [], isLoading: messagesLoading, refetch: refetchMessages } = useQuery<Message[]>({
    queryKey: ["/api/conversations", params.id, "messages"],
    queryFn: async () => {
      const res = await fetch(`/api/conversations/${params.id}/messages`);
      return res.json();
    },
    refetchInterval: 5000,
  });

  const sendMessage = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", `/api/conversations/${params.id}/messages`, { content });
      return res.json();
    },
    onSuccess: () => {
      setMessage("");
      refetchMessages();
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to send message", variant: "destructive" });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (!user?.id) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
    
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: "auth", userId: user.id }));
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "new_message" && data.conversationId === parseInt(params.id!)) {
          refetchMessages();
        }
      } catch (e) {
        console.error("WebSocket message error:", e);
      }
    };

    wsRef.current = ws;

    return () => {
      ws.close();
    };
  }, [user?.id, params.id, refetchMessages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      sendMessage.mutate(message.trim());
    }
  };

  const getOtherUser = () => {
    if (!conversation) return null;
    return conversation.buyerId === user?.id ? conversation.seller : conversation.buyer;
  };

  const getInitials = (u: { firstName?: string | null; lastName?: string | null; email?: string | null } | null | undefined) => {
    if (u?.firstName && u?.lastName) {
      return `${u.firstName[0]}${u.lastName[0]}`.toUpperCase();
    }
    if (u?.email) {
      return u.email[0].toUpperCase();
    }
    return "U";
  };

  const formatMessageDate = (dateStr: string | Date) => {
    const date = new Date(dateStr);
    if (isToday(date)) {
      return format(date, "h:mm a");
    }
    if (isYesterday(date)) {
      return `Yesterday ${format(date, "h:mm a")}`;
    }
    return format(date, "MMM d, h:mm a");
  };

  const formatPrice = (price: string | number) => {
    const num = typeof price === "string" ? parseFloat(price) : price;
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  };

  if (convLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-[60vh] rounded-lg" />
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8 text-center">
        <p className="text-muted-foreground">Conversation not found</p>
        <Link href="/messages">
          <Button variant="outline" className="mt-4">Back to Messages</Button>
        </Link>
      </div>
    );
  }

  const otherUser = getOtherUser();

  return (
    <div className="max-w-3xl mx-auto px-4 py-4 flex flex-col h-[calc(100vh-4rem)]">
      <div className="flex items-center gap-4 pb-4 border-b">
        <Link href="/messages">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <Avatar className="h-10 w-10">
          <AvatarImage src={otherUser?.profileImageUrl || undefined} className="object-cover" />
          <AvatarFallback>{getInitials(otherUser)}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="font-medium truncate">
            {otherUser?.firstName 
              ? `${otherUser.firstName} ${otherUser.lastName || ""}`
              : "User"}
          </p>
          <p className="text-sm text-muted-foreground truncate">
            {conversation.product.title}
          </p>
        </div>
        <Link href={`/product/${conversation.product.id}`}>
          <Button variant="outline" size="sm" className="gap-1 shrink-0" data-testid="link-product">
            <ExternalLink className="h-4 w-4" />
            View Item
          </Button>
        </Link>
      </div>

      <Card className="mt-4 shrink-0">
        <CardContent className="flex items-center gap-3 p-3">
          <div className="h-12 w-12 rounded-lg overflow-hidden bg-muted shrink-0">
            <img 
              src={conversation.product.images?.[0] || "https://placehold.co/100x100/e2e8f0/94a3b8?text=No+Image"} 
              alt={conversation.product.title}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate">{conversation.product.title}</p>
            <p className="text-lg font-bold">{formatPrice(conversation.product.price)}</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex-1 overflow-y-auto py-4 space-y-4">
        {messagesLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className={cn("flex", i % 2 === 0 ? "justify-end" : "justify-start")}>
              <Skeleton className="h-12 w-48 rounded-lg" />
            </div>
          ))
        ) : messages.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isOwn = msg.senderId === user?.id;
            return (
              <div key={msg.id} className={cn("flex", isOwn ? "justify-end" : "justify-start")}>
                <div 
                  className={cn(
                    "max-w-[75%] rounded-lg px-4 py-2",
                    isOwn 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted"
                  )}
                  data-testid={`message-${msg.id}`}
                >
                  <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                  <p className={cn(
                    "text-xs mt-1",
                    isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
                  )}>
                    {msg.createdAt && formatMessageDate(msg.createdAt)}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2 pt-4 border-t">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1"
          disabled={sendMessage.isPending}
          data-testid="input-message"
        />
        <Button 
          type="submit" 
          size="icon"
          disabled={!message.trim() || sendMessage.isPending}
          data-testid="button-send"
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}

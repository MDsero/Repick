import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { ProductGrid } from "@/components/product-grid";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithSeller, User } from "@shared/schema";
import { MapPin, Calendar, Loader2, Save } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Profile() {
  const params = useParams<{ id?: string }>();
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  
  const isOwnProfile = !params.id || params.id === currentUser?.id;
  const userId = params.id || currentUser?.id;

  const [phone, setPhone] = useState("");
  const [location, setLocation] = useState("");
  const [bio, setBio] = useState("");

  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/users", userId],
    queryFn: async () => {
      if (isOwnProfile) {
        const res = await fetch("/api/auth/user");
        return res.json();
      }
      const res = await fetch(`/api/users/${userId}`);
      return res.json();
    },
    enabled: !!userId,
  });

  const { data: products = [], isLoading: productsLoading } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/products", "seller", userId],
    queryFn: async () => {
      const res = await fetch(`/api/products?seller=${userId}&status=active`);
      return res.json();
    },
    enabled: !!userId,
  });

  useEffect(() => {
    if (user && isOwnProfile) {
      setPhone(user.phone || "");
      setLocation(user.location || "");
      setBio(user.bio || "");
    }
  }, [user, isOwnProfile]);

  const updateProfile = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", "/api/users/profile", { phone, location, bio });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId] });
      toast({ title: "Profile updated!" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update profile", variant: "destructive" });
    },
  });

  const getInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return "U";
  };

  if (userLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <div className="flex items-center gap-6">
          <Skeleton className="h-24 w-24 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <Skeleton className="h-64 rounded-lg" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-16 text-center">
        <p className="text-muted-foreground">User not found</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col sm:flex-row items-start gap-6">
        <Avatar className="h-24 w-24">
          <AvatarImage src={user.profileImageUrl || undefined} className="object-cover" />
          <AvatarFallback className="text-2xl">{getInitials()}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h1 className="text-2xl font-bold" data-testid="text-name">
            {user.firstName 
              ? `${user.firstName} ${user.lastName || ""}`
              : user.email?.split("@")[0] || "User"}
          </h1>
          <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
            {user.location && (
              <span className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {user.location}
              </span>
            )}
            {user.createdAt && (
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                Member {formatDistanceToNow(new Date(user.createdAt), { addSuffix: true })}
              </span>
            )}
          </div>
          {user.bio && (
            <p className="mt-4 text-muted-foreground">{user.bio}</p>
          )}
        </div>
      </div>

      {isOwnProfile && (
        <Card>
          <CardHeader>
            <CardTitle>Edit Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Your phone number"
                  data-testid="input-phone"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="City, State"
                  data-testid="input-location"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell buyers a bit about yourself..."
                rows={3}
                data-testid="input-bio"
              />
            </div>
            <Button 
              onClick={() => updateProfile.mutate()}
              disabled={updateProfile.isPending}
              data-testid="button-save"
            >
              {updateProfile.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        <h2 className="text-xl font-bold">
          {isOwnProfile ? "Your Listings" : "Listings"}
        </h2>
        <ProductGrid products={products} isLoading={productsLoading} />
      </div>
    </div>
  );
}

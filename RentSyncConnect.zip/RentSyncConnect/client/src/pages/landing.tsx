import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { ProductGrid } from "@/components/product-grid";
import { CategoryPills } from "@/components/category-pills";
import type { ProductWithSeller, Category } from "@shared/schema";
import { useState } from "react";
import { 
  ShoppingBag, 
  Shield, 
  MessageCircle, 
  TrendingUp,
  ArrowRight,
} from "lucide-react";

export default function Landing() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);

  const { data: products = [], isLoading: productsLoading } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/products", selectedCategory],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory) params.set("category", selectedCategory.toString());
      params.set("limit", "12");
      const res = await fetch(`/api/products?${params}`);
      return res.json();
    },
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  return (
    <div>
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-accent/10 py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight">
              Buy & Sell <span className="text-primary">Locally</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
              Find great deals on used items in your community. 
              Post your items for free and connect with buyers nearby.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a href="/api/login">
                <Button size="lg" className="gap-2 w-full sm:w-auto" data-testid="button-start-selling">
                  <ShoppingBag className="h-5 w-5" />
                  Start Selling
                </Button>
              </a>
              <Button variant="outline" size="lg" className="gap-2" asChild>
                <Link href="#browse" data-testid="button-browse">
                  Browse Items
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <Card className="p-6 text-center space-y-3">
              <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Safe & Secure</h3>
              <p className="text-sm text-muted-foreground">
                Verified users and secure messaging protect your transactions
              </p>
            </Card>
            <Card className="p-6 text-center space-y-3">
              <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageCircle className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Direct Chat</h3>
              <p className="text-sm text-muted-foreground">
                Message sellers instantly and negotiate the best deals
              </p>
            </Card>
            <Card className="p-6 text-center space-y-3">
              <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Free Listings</h3>
              <p className="text-sm text-muted-foreground">
                Post unlimited items for free and reach thousands of buyers
              </p>
            </Card>
          </div>
        </div>
      </section>

      <section id="browse" className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Browse Products</h2>
            <a href="/api/login">
              <Button variant="ghost" size="sm" className="gap-1" data-testid="link-view-all">
                View All
                <ArrowRight className="h-4 w-4" />
              </Button>
            </a>
          </div>

          {categories.length > 0 && (
            <CategoryPills
              categories={categories}
              selectedId={selectedCategory}
              onSelect={setSelectedCategory}
            />
          )}

          <ProductGrid products={products} isLoading={productsLoading} />
        </div>
      </section>

      <section className="py-16 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl font-bold">Ready to start?</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Join thousands of people buying and selling in your community. 
            It's free and takes just seconds to get started.
          </p>
          <a href="/api/login">
            <Button size="lg" data-testid="button-join">Join MarketHub</Button>
          </a>
        </div>
      </section>
    </div>
  );
}

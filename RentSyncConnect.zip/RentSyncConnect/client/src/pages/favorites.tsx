import { useQuery } from "@tanstack/react-query";
import { ProductGrid } from "@/components/product-grid";
import type { ProductWithSeller } from "@shared/schema";
import { Heart } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Favorites() {
  const { data: products = [], isLoading, refetch } = useQuery<ProductWithSeller[]>({
    queryKey: ["/api/favorites"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      <h1 className="text-2xl font-bold">My Favorites</h1>

      {!isLoading && products.length === 0 ? (
        <div className="text-center py-16">
          <Heart className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold mb-2">No favorites yet</h2>
          <p className="text-muted-foreground mb-6">
            Start browsing and save items you love!
          </p>
          <Link href="/">
            <Button data-testid="button-browse">Browse Products</Button>
          </Link>
        </div>
      ) : (
        <ProductGrid 
          products={products} 
          isLoading={isLoading}
          onFavoriteChange={() => refetch()}
        />
      )}
    </div>
  );
}

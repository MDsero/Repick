import {
  users,
  products,
  categories,
  favorites,
  conversations,
  messages,
  type User,
  type UpsertUser,
  type Product,
  type InsertProduct,
  type Category,
  type InsertCategory,
  type Favorite,
  type InsertFavorite,
  type Conversation,
  type InsertConversation,
  type Message,
  type InsertMessage,
  type ProductWithSeller,
  type ConversationWithDetails,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, sql, ilike, gte, lte, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations - Required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, data: Partial<UpsertUser>): Promise<User | undefined>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Product operations
  getProducts(filters?: {
    categoryId?: number;
    sellerId?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    condition?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<ProductWithSeller[]>;
  getProduct(id: number): Promise<ProductWithSeller | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  incrementProductViews(id: number): Promise<void>;
  
  // Favorites operations
  getFavorites(userId: string): Promise<ProductWithSeller[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: string, productId: number): Promise<boolean>;
  isFavorite(userId: string, productId: number): Promise<boolean>;
  
  // Conversation operations
  getConversations(userId: string): Promise<ConversationWithDetails[]>;
  getConversation(id: number): Promise<ConversationWithDetails | undefined>;
  getOrCreateConversation(productId: number, buyerId: string, sellerId: string): Promise<Conversation>;
  
  // Message operations
  getMessages(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessagesAsRead(conversationId: number, userId: string): Promise<void>;
  getUnreadCount(userId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, data: Partial<UpsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(categories.name);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [created] = await db.insert(categories).values(category).returning();
    return created;
  }

  // Product operations
  async getProducts(filters?: {
    categoryId?: number;
    sellerId?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    condition?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<ProductWithSeller[]> {
    const conditions = [];
    
    if (filters?.status) {
      conditions.push(eq(products.status, filters.status));
    } else {
      conditions.push(eq(products.status, "active"));
    }
    
    if (filters?.categoryId) {
      conditions.push(eq(products.categoryId, filters.categoryId));
    }
    
    if (filters?.sellerId) {
      conditions.push(eq(products.sellerId, filters.sellerId));
    }
    
    if (filters?.search) {
      conditions.push(
        or(
          ilike(products.title, `%${filters.search}%`),
          ilike(products.description, `%${filters.search}%`)
        )
      );
    }
    
    if (filters?.minPrice) {
      conditions.push(gte(products.price, filters.minPrice.toString()));
    }
    
    if (filters?.maxPrice) {
      conditions.push(lte(products.price, filters.maxPrice.toString()));
    }
    
    if (filters?.condition) {
      conditions.push(eq(products.condition, filters.condition));
    }

    const query = db
      .select({
        product: products,
        seller: users,
        category: categories,
      })
      .from(products)
      .leftJoin(users, eq(products.sellerId, users.id))
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(products.createdAt))
      .limit(filters?.limit || 50)
      .offset(filters?.offset || 0);

    const results = await query;
    
    return results.map(r => ({
      ...r.product,
      seller: r.seller!,
      category: r.category,
    }));
  }

  async getProduct(id: number): Promise<ProductWithSeller | undefined> {
    const [result] = await db
      .select({
        product: products,
        seller: users,
        category: categories,
      })
      .from(products)
      .leftJoin(users, eq(products.sellerId, users.id))
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(products.id, id));
    
    if (!result) return undefined;
    
    return {
      ...result.product,
      seller: result.seller!,
      category: result.category,
    };
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [created] = await db.insert(products).values(product).returning();
    return created;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set({ ...product, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return updated;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id)).returning();
    return result.length > 0;
  }

  async incrementProductViews(id: number): Promise<void> {
    await db
      .update(products)
      .set({ views: sql`${products.views} + 1` })
      .where(eq(products.id, id));
  }

  // Favorites operations
  async getFavorites(userId: string): Promise<ProductWithSeller[]> {
    const results = await db
      .select({
        product: products,
        seller: users,
        category: categories,
      })
      .from(favorites)
      .innerJoin(products, eq(favorites.productId, products.id))
      .leftJoin(users, eq(products.sellerId, users.id))
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(favorites.userId, userId))
      .orderBy(desc(favorites.createdAt));
    
    return results.map(r => ({
      ...r.product,
      seller: r.seller!,
      category: r.category,
      isFavorite: true,
    }));
  }

  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [created] = await db.insert(favorites).values(favorite).returning();
    return created;
  }

  async removeFavorite(userId: string, productId: number): Promise<boolean> {
    const result = await db
      .delete(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.productId, productId)))
      .returning();
    return result.length > 0;
  }

  async isFavorite(userId: string, productId: number): Promise<boolean> {
    const [result] = await db
      .select()
      .from(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.productId, productId)));
    return !!result;
  }

  // Conversation operations
  async getConversations(userId: string): Promise<ConversationWithDetails[]> {
    const results = await db
      .select({
        conversation: conversations,
        product: products,
        buyer: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          phone: users.phone,
          location: users.location,
          bio: users.bio,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(conversations)
      .innerJoin(products, eq(conversations.productId, products.id))
      .innerJoin(users, eq(conversations.buyerId, users.id))
      .where(or(eq(conversations.buyerId, userId), eq(conversations.sellerId, userId)))
      .orderBy(desc(conversations.lastMessageAt));
    
    const conversationDetails: ConversationWithDetails[] = [];
    
    for (const r of results) {
      // Get seller info
      const [seller] = await db.select().from(users).where(eq(users.id, r.conversation.sellerId));
      
      // Get last message
      const [lastMessage] = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, r.conversation.id))
        .orderBy(desc(messages.createdAt))
        .limit(1);
      
      // Get unread count
      const [unreadResult] = await db
        .select({ count: sql<number>`count(*)` })
        .from(messages)
        .where(
          and(
            eq(messages.conversationId, r.conversation.id),
            eq(messages.receiverId, userId),
            eq(messages.read, false)
          )
        );
      
      conversationDetails.push({
        ...r.conversation,
        product: r.product,
        buyer: r.buyer as User,
        seller: seller,
        lastMessage,
        unreadCount: Number(unreadResult?.count || 0),
      });
    }
    
    return conversationDetails;
  }

  async getConversation(id: number): Promise<ConversationWithDetails | undefined> {
    const [result] = await db
      .select({
        conversation: conversations,
        product: products,
      })
      .from(conversations)
      .innerJoin(products, eq(conversations.productId, products.id))
      .where(eq(conversations.id, id));
    
    if (!result) return undefined;
    
    const [buyer] = await db.select().from(users).where(eq(users.id, result.conversation.buyerId));
    const [seller] = await db.select().from(users).where(eq(users.id, result.conversation.sellerId));
    
    return {
      ...result.conversation,
      product: result.product,
      buyer,
      seller,
    };
  }

  async getOrCreateConversation(productId: number, buyerId: string, sellerId: string): Promise<Conversation> {
    const [existing] = await db
      .select()
      .from(conversations)
      .where(
        and(
          eq(conversations.productId, productId),
          eq(conversations.buyerId, buyerId)
        )
      );
    
    if (existing) return existing;
    
    const [created] = await db
      .insert(conversations)
      .values({ productId, buyerId, sellerId })
      .returning();
    return created;
  }

  // Message operations
  async getMessages(conversationId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [created] = await db.insert(messages).values(message).returning();
    
    // Update conversation last message time
    await db
      .update(conversations)
      .set({ lastMessageAt: new Date() })
      .where(eq(conversations.id, message.conversationId));
    
    return created;
  }

  async markMessagesAsRead(conversationId: number, userId: string): Promise<void> {
    await db
      .update(messages)
      .set({ read: true })
      .where(
        and(
          eq(messages.conversationId, conversationId),
          eq(messages.receiverId, userId)
        )
      );
  }

  async getUnreadCount(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)` })
      .from(messages)
      .where(and(eq(messages.receiverId, userId), eq(messages.read, false)));
    return Number(result?.count || 0);
  }
}

export const storage = new DatabaseStorage();

import { db } from "./db";
import { categories } from "@shared/schema";

const defaultCategories = [
  { name: "Electronics", slug: "electronics", icon: "laptop", description: "Phones, computers, and gadgets" },
  { name: "Vehicles", slug: "vehicles", icon: "car", description: "Cars, motorcycles, and bikes" },
  { name: "Furniture", slug: "furniture", icon: "sofa", description: "Home and office furniture" },
  { name: "Clothing", slug: "clothing", icon: "shirt", description: "Apparel and accessories" },
  { name: "Sports", slug: "sports", icon: "dumbbell", description: "Sports equipment and gear" },
  { name: "Books", slug: "books", icon: "book", description: "Books, magazines, and educational materials" },
  { name: "Games", slug: "games", icon: "gamepad", description: "Video games and consoles" },
  { name: "Home & Garden", slug: "home-garden", icon: "home", description: "Home improvement and gardening" },
  { name: "Baby & Kids", slug: "baby-kids", icon: "baby", description: "Baby items and children's products" },
  { name: "Music", slug: "music", icon: "music", description: "Musical instruments and equipment" },
  { name: "Tools", slug: "tools", icon: "wrench", description: "Power tools and hand tools" },
];

export async function seedCategories() {
  try {
    const existing = await db.select().from(categories);
    if (existing.length === 0) {
      await db.insert(categories).values(defaultCategories);
      console.log("Seeded categories successfully");
    } else {
      console.log("Categories already exist, skipping seed");
    }
  } catch (error) {
    console.error("Error seeding categories:", error);
  }
}

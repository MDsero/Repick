import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProductSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { seedCategories } from "./seed";

// Configure multer for image uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage: multerStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error("Only image files are allowed"));
  },
});

// WebSocket connections map
const wsConnections = new Map<string, WebSocket>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Seed categories
  await seedCategories();

  // Serve uploaded images
  app.use("/uploads", (req, res, next) => {
    res.setHeader("Cache-Control", "public, max-age=31536000");
    next();
  }, express.static(uploadDir));

  // Auth routes
  app.get("/api/auth/user", async (req: any, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user profile
  app.patch("/api/users/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { phone, location, bio } = req.body;
      const user = await storage.updateUser(userId, { phone, location, bio });
      res.json(user);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't expose email for other users
      const { email, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const cats = await storage.getCategories();
      res.json(cats);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const { category, search, minPrice, maxPrice, condition, seller, limit, offset } = req.query;
      const products = await storage.getProducts({
        categoryId: category ? parseInt(category as string) : undefined,
        search: search as string,
        minPrice: minPrice ? parseFloat(minPrice as string) : undefined,
        maxPrice: maxPrice ? parseFloat(maxPrice as string) : undefined,
        condition: condition as string,
        sellerId: seller as string,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      });
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Increment views
      await storage.incrementProductViews(id);
      
      // Check if favorited by current user
      if ((req as any).isAuthenticated?.()) {
        const userId = (req as any).user?.claims?.sub;
        if (userId) {
          product.isFavorite = await storage.isFavorite(userId, id);
        }
      }
      
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", isAuthenticated, upload.array("images", 8), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const files = req.files as Express.Multer.File[];
      const images = files?.map(f => `/uploads/${f.filename}`) || [];
      
      const productData = {
        title: req.body.title,
        description: req.body.description,
        price: req.body.price,
        condition: req.body.condition || "good",
        categoryId: req.body.categoryId ? parseInt(req.body.categoryId) : null,
        location: req.body.location,
        images,
        sellerId: userId,
        status: "active",
        featured: false,
      };
      
      const parsed = insertProductSchema.safeParse(productData);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid product data", errors: parsed.error.errors });
      }
      
      const product = await storage.createProduct(parsed.data);
      res.status(201).json(product);
    } catch (error) {
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.patch("/api/products/:id", isAuthenticated, upload.array("newImages", 8), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      
      const existing = await storage.getProduct(id);
      if (!existing) {
        return res.status(404).json({ message: "Product not found" });
      }
      if (existing.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const files = req.files as Express.Multer.File[];
      const newImages = files?.map(f => `/uploads/${f.filename}`) || [];
      const existingImages = req.body.existingImages ? JSON.parse(req.body.existingImages) : [];
      const images = [...existingImages, ...newImages];
      
      const updateData: any = {};
      if (req.body.title) updateData.title = req.body.title;
      if (req.body.description) updateData.description = req.body.description;
      if (req.body.price) updateData.price = req.body.price;
      if (req.body.condition) updateData.condition = req.body.condition;
      if (req.body.categoryId) updateData.categoryId = parseInt(req.body.categoryId);
      if (req.body.location) updateData.location = req.body.location;
      if (req.body.status) updateData.status = req.body.status;
      if (images.length > 0) updateData.images = images;
      
      const product = await storage.updateProduct(id, updateData);
      res.json(product);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      
      const existing = await storage.getProduct(id);
      if (!existing) {
        return res.status(404).json({ message: "Product not found" });
      }
      if (existing.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      await storage.deleteProduct(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Favorites routes
  app.get("/api/favorites", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const faves = await storage.getFavorites(userId);
      res.json(faves);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites/:productId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const productId = parseInt(req.params.productId);
      
      const exists = await storage.isFavorite(userId, productId);
      if (exists) {
        return res.status(400).json({ message: "Already in favorites" });
      }
      
      const favorite = await storage.addFavorite({ userId, productId });
      res.status(201).json(favorite);
    } catch (error) {
      console.error("Error adding favorite:", error);
      res.status(500).json({ message: "Failed to add favorite" });
    }
  });

  app.delete("/api/favorites/:productId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const productId = parseInt(req.params.productId);
      
      await storage.removeFavorite(userId, productId);
      res.status(204).send();
    } catch (error) {
      console.error("Error removing favorite:", error);
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // Conversation routes
  app.get("/api/conversations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const convos = await storage.getConversations(userId);
      res.json(convos);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.get("/api/conversations/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const id = parseInt(req.params.id);
      
      const convo = await storage.getConversation(id);
      if (!convo) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      if (convo.buyerId !== userId && convo.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      res.json(convo);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.post("/api/conversations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { productId, sellerId } = req.body;
      
      if (userId === sellerId) {
        return res.status(400).json({ message: "Cannot message yourself" });
      }
      
      const convo = await storage.getOrCreateConversation(productId, userId, sellerId);
      res.json(convo);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  // Message routes
  app.get("/api/conversations/:id/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversationId = parseInt(req.params.id);
      
      const convo = await storage.getConversation(conversationId);
      if (!convo) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      if (convo.buyerId !== userId && convo.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Mark messages as read
      await storage.markMessagesAsRead(conversationId, userId);
      
      const msgs = await storage.getMessages(conversationId);
      res.json(msgs);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/conversations/:id/messages", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const conversationId = parseInt(req.params.id);
      
      const convo = await storage.getConversation(conversationId);
      if (!convo) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      if (convo.buyerId !== userId && convo.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const receiverId = convo.buyerId === userId ? convo.sellerId : convo.buyerId;
      
      const messageData = {
        conversationId,
        senderId: userId,
        receiverId,
        content: req.body.content,
      };
      
      const parsed = insertMessageSchema.safeParse(messageData);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid message", errors: parsed.error.errors });
      }
      
      const message = await storage.createMessage(parsed.data);
      
      // Notify via WebSocket
      const receiverWs = wsConnections.get(receiverId);
      if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
        receiverWs.send(JSON.stringify({
          type: "new_message",
          message,
          conversationId,
        }));
      }
      
      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // Unread count
  app.get("/api/messages/unread", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  // My listings
  app.get("/api/my/listings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { status } = req.query;
      const products = await storage.getProducts({
        sellerId: userId,
        status: status as string || undefined,
      });
      res.json(products);
    } catch (error) {
      console.error("Error fetching listings:", error);
      res.status(500).json({ message: "Failed to fetch listings" });
    }
  });

  // Image upload endpoint
  app.post("/api/upload", isAuthenticated, upload.single("image"), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      res.json({ url: `/uploads/${req.file.filename}` });
    } catch (error) {
      console.error("Error uploading:", error);
      res.status(500).json({ message: "Failed to upload" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time messaging
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  
  wss.on("connection", (ws, req) => {
    let userId: string | null = null;
    
    ws.on("message", (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === "auth" && message.userId) {
          userId = message.userId;
          wsConnections.set(userId, ws);
        }
      } catch (e) {
        console.error("WebSocket message error:", e);
      }
    });
    
    ws.on("close", () => {
      if (userId) {
        wsConnections.delete(userId);
      }
    });
  });

  return httpServer;
}
